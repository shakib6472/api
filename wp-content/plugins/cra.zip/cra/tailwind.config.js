module.exports = {
    content: ["./templates/**/*.php", "./includes/**/*.php"],
    theme: {
      extend: {},
    },
    plugins: [],
  }
  